package main;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.util.HashMap;
import java.util.Properties;





public class EmailRecord {

	private String fromEmail;
	private String toEmail;
	private String subjectEmail;
	private String bodyEmail;
	
	public EmailRecord(String fromEmail, String toEmail, String subjectEmail, String bodyEmail) {
		this.fromEmail = fromEmail;
		this.toEmail = toEmail;
		this.subjectEmail = subjectEmail;
		this.bodyEmail = bodyEmail;
		
	}
	
	/**
	 * Method returns true if email successfully sent
	 */
	public boolean sendEmail(HashMap<String,String> credentials) {
		////// Set-up email server ///////
		String host = credentials.get("smtphost");
		String port = credentials.get("smtpport");
		
		Properties props = new Properties();
		props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.smtp.host", host);
		props.setProperty("mail.smtp.port", port);
		
		////// Authenticate //////
		String user = credentials.get("smtpuser");
		String pass = credentials.get("smtppass");
		
		props.setProperty("mail.smtp.auth", "true");
		Authenticator authenticator = new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, pass);
			}
		};
		
		Session session = Session.getDefaultInstance(props, authenticator);
		
		//// Try to send email ////
		try {
			MimeMessage msg = new MimeMessage(session);
			
			// Set from & to headers
			msg.setFrom(fromEmail);
			msg.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
			
			// Set subject line
			msg.setSubject(subjectEmail);
			
			// Set message body
			msg.setText(bodyEmail);
			
			// Actually send message
			Transport.send(msg);
			System.out.println("Sent message successfully....");
			
		} catch(MessagingException e) {
			System.out.println("Messaging Exception for email with subject: " + subjectEmail);
		}
		
		
		
		
		return false;
	}

}
