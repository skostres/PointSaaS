package main;

import org.stringtemplate.v4.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;



public class Main {

	/**
	 * Main method of Email Scheduler
	 * @param args
	 */
	public static void main(String args[]) {
		
		// Database log-in information from configuration.cfg
		HashMap<String, String> dbCredentials = new HashMap<String, String>();
		
		// HashMap for DB columns and records
		HashMap<String, String> dbInfo = new HashMap<String, String>();
		
		//////////////// Read configuration.cfg ////////////////
		readConfig(dbCredentials);
		
		//////////////// Connect to SQL Server /////////////////
		// Had some errors connecting to SQL Server - accept TCP/IP on port; make sure SQL Server Browser process is running
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
			Connection conn = DriverManager.getConnection("jdbc:sqlserver://" + dbCredentials.get("sqlhost") + ";user=" 
															+ dbCredentials.get("sqluser") + ";password=" 
															+ dbCredentials.get("sqlpass") + ";database=" 
															+ dbCredentials.get("sqldb"));
			
			Statement sta = conn.createStatement();
			String Sql = "SELECT sl.ServerURL+ins.URL AS 'fullurl', q.ID AS EmailID, IT.ID AS InstanceTypeID,* FROM [EmailQueues] q INNER JOIN Users u ON u.ID = q.Owner_ID "
				+ "INNER JOIN EmailTemplates emt ON emt.ID = q.Template_ID INNER JOIN Instances ins ON ins.ID = q.Instance_ID "
				+ "INNER JOIN InstanceTypes IT ON IT.ID = ins.InstanceType_ID INNER JOIN ServerLocations sl ON sl.ID = ins.LocationInstalled_ID "
				+ "WHERE SYSDATETIME() > FutureTime AND IsReady = 1;";
			ResultSet rs = sta.executeQuery(Sql);
		
			// Get DB metadata and initialize HashMap with keys=DB Columns & rows=null for now
			ResultSetMetaData rsdata = rs.getMetaData();
			int colSize = rsdata.getColumnCount();
			
			for(int i=1; i <= colSize; i++) {
				String colName = rsdata.getColumnName(i);
				dbInfo.put(colName, null);
			}
			
			
			// Go through each record and store each record value in respective column in HashMap
			while (rs.next()) {				
				// Fill each K-V pair with appropriate data from this record
				for(String s : dbInfo.keySet()) {
					dbInfo.put(s, rs.getString(s));
				}
				
				// Create new EmailRecord and add it to list of emails to be sent
				EmailRecord emailInstance = emailQueueCreate(dbInfo);
				
				//Send email for this record
				emailInstance.sendEmail(dbCredentials);
				
				// DELETE record from database after each processing
				Statement sta2 = conn.createStatement();
				String deleteSQL = "DELETE FROM EmailQueues WHERE ID = " + dbInfo.get("EmailID");
				sta2.executeQuery(Sql);
			}

			
		} catch(SQLException | ClassNotFoundException e) {
			System.out.println("Error with SQL Querying " + e.toString());
		}

	}
	
	/**
	 * Method to create a queue of emails to be sent
	 * @return
	 */
	private static EmailRecord emailQueueCreate(HashMap<String, String> dbInfo) {
		//String fromEmail, String toEmail, String subjectEmail, String bodyEmail
		
		String body = null;
		
		String fromEmail = dbInfo.get("Email");
		String toEmail = dbInfo.get("Email");
		String subjectEmail = dbInfo.get("EmailSubject");
		
		String instanceID = dbInfo.get("InstanceTypeID");
		String templateName = dbInfo.get("TemplateFileName");
		
		body = createBody(instanceID, templateName, dbInfo);
		
		// Creating new EmailRecord with given data for this specific record in DB		
		EmailRecord emailInstance = new EmailRecord(fromEmail, toEmail, subjectEmail, body);
		
		return emailInstance;
	}
	
	
	/**
	 * Formatting the body of the email
	 */
	private static String createBody(String imageIDString, String templateName, HashMap<String, String> dbInfo) {
		
		int imageID = Integer.parseInt(imageIDString); 	
		
		String templateName2 = null;
		String templateNoExt = null;
		
		// Convert to a STGroupFile if is in ".tpl" or ".st" -- won't cause any errors in conversion since they are all basically the same
		if(templateName.endsWith(".tpl")) {
			templateNoExt = templateName.substring(0, templateName.indexOf("."));
			templateName2 = templateNoExt + ".stg";
		}
		
	    
		///////////////// Accessing templates ///////////////////
		
	    STGroup g2 = new STGroupFile("/PointSaaS/EmailTemplates/" + imageID + "/" + templateName2);
	    
	    ST temp2 = g2.getInstanceOf(templateNoExt);
	    
	    temp2.add("firstname",dbInfo.get("FirstName"));
	    temp2.add("username", dbInfo.get("SysUser"));
		temp2.add("password", dbInfo.get("SysPass"));
		temp2.add("supportEmail", dbInfo.get("Email"));
		String rendered = temp2.render();
		
	    //System.out.println(rendered);
	    
		return rendered.toString();
	}


	/**
	 * Helper to read config file to get log in info for SQL server
	 */
	private static void readConfig(HashMap<String, String> creds) {
		
		String filePath = "C:\\PointSaaS\\configuration.cfg";
		
		BufferedReader bufRead = null;
		FileReader fRead = null;
		String line = null;
		int lineNum = 0;
		
		
		try {
			
			fRead = new FileReader(filePath);
			bufRead = new BufferedReader(fRead);
			
			
			while((line = bufRead.readLine()) != null) {
				String[] split = line.split("=");
				creds.put(split[0].toLowerCase(), split[1]);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("configuration.cfg file not found in C:\\PointSaaS");
		} catch (IOException e) {
			System.out.println("Error reading configurationg.cfg");
		}
	}

	


}











